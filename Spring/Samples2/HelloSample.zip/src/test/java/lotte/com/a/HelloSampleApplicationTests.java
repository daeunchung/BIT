package lotte.com.a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
