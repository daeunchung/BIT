package dto;

public class ReservationDto {

}
