package dto;

public class LocationDto {

}
